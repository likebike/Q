echo $(date +%k:%M:%S.%N) Starting $$
sleep $@
echo $(date +%k:%M:%S.%N) "       Ending" $$
