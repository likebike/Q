#include <stdio.h>   // printf, fprintf
#include <stdlib.h>  // exit, rand
#include <time.h>    // time

// http://stackoverflow.com/questions/1598773/is-there-a-standard-function-in-c-that-would-return-the-length-of-an-array#1598827
#define COUNT_OF(x) ((sizeof(x)/sizeof(0[x])) / ((size_t)(!(sizeof(x) % sizeof(0[x])))))

typedef struct _intPair {
    int first;
    int last;
} intPair;

int LOCKS[10000];
int LOCKS_LEN = COUNT_OF(LOCKS);

void populate_LOCKS(int start_index, int end_index) {
    int i;

    // check for overflow
    if (end_index > (LOCKS_LEN - 1)) {
        fprintf(stderr, "Warning: end_index exceeded LOCKS_LEN, using maximum length");
        end_index = LOCKS_LEN - 1;
    }

    // init to 0
    for (i=0; i<LOCKS_LEN; i++) {
        LOCKS[i] = 0;
    }

    // fill range with 1
    for (i=start_index; i<=end_index; i++) {
        LOCKS[i] = 1;
    }

    // insert some zeroes
    for (i=start_index+1; i<=(end_index-1); i++) {
        if ((rand() % 2) - 1 == 0) {
            LOCKS[i] = 0;
        }
    }
}


int binary_search(int lowI, int highI, int (*targetIsLessThanMidpoint)(int)) {
    if(lowI == highI) return lowI;
    int midPoint = lowI + (highI-lowI)/2;
    if(midPoint == lowI) midPoint++;  // Due to the fact that we are using "less than" comparisons, take the higher one.
    if(targetIsLessThanMidpoint(midPoint)) return binary_search(lowI, midPoint-1, targetIsLessThanMidpoint);
    return binary_search(midPoint, highI, targetIsLessThanMidpoint);
}


int isPositionPastAllLocks(int i) {
    for (; i<LOCKS_LEN; i++) {
        if (LOCKS[i] == 1) return 0;
    }
    return 1;
}

int isSomethingBelowLocked(int i) {
    int z = 0;
    for (z=0; z<i; z++) {
        if (LOCKS[z] == 1) return 1;
    }
    return 0;
}

intPair find_firstAndLast_slots() {
    intPair result = {-1, -1};
    int i = 1;

    while(1) {
        if (isPositionPastAllLocks(i)) break;
        i *= 2;
    }

    // now we know that the end is somewhere between (i/2) and (i), and we can use a binary search
    result.last = binary_search(i/2, i, isPositionPastAllLocks);

    if(result.last < 0) return result;  // The first slot will also be -1.

    // now we need to find the front, which is between 0 and result.last. We also use a binary search for this
    result.first = binary_search(0, result.last, isSomethingBelowLocked);

    return result;
}

void testCombinations() {
    int testPairs_LEN = 10000;

    srand(time(NULL));

    intPair testPairs[testPairs_LEN];
    intPair xy;

    int i;
    for (i=0; i<testPairs_LEN; i++) {
        int val1 = rand() % LOCKS_LEN;
        int val2 = rand() % LOCKS_LEN;

        if (val1 < val2) {
            testPairs[i].first = val1;
            testPairs[i].last = val2;
        } else {
            testPairs[i].first = val2;
            testPairs[i].last = val1;
        }
    }

    for (i=0; i<testPairs_LEN; i++) {
        populate_LOCKS(testPairs[i].first, testPairs[i].last);
        xy = find_firstAndLast_slots();
        if (xy.first != testPairs[i].first) {
            printf("Error -- result.first mismatch!\n");
        }
        if (xy.last != testPairs[i].last) {
            printf("Error -- result.last mismatch!\n");
        }
    }

    return;
}


int main(int argc, char** argv) {
    testCombinations();
    return 0;
}

