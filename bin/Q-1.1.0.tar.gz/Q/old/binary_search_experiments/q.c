// Q - By Christopher Sebastian 2013-07-29.  BSD License.
// This is a process queue "wrapper", able to run a number of workers concurrently.
// Created to limit the number of simultaneous CGI worker processes, but can
// probably be used for many other things too.
// Runs workers in a FIFO order (in the order they are launched).
//
// Limits:
//   1) Currently uses Record Locking for IPC and exec to launch the target process.
//      Therefore, if the target command does something like closing all file
//      descriptors, the lock will be released and this might mess up the
//      concurrency tracking (enabling many more to run at once).
//      I will solve this problem if/when I encounter it in real life.
//
//   2) You should never run this program as SUID.  It is not secure because it
//      is currently influenced by environment variables (HOME, PATH, etc), and
//      it currently uses the very powerful 'wordexp' function.
//      Right now, I assume that the user is intelligent and trustworthy.
//      As long as this is not run with SUID, it should not expose any new
//      security vulnerabilities.


// TODO: Just use basename for arg[0] when exec'ing.  // Need more research.
//       Implement binary search algorithm
//       Error log file
//       Fix web324 avio (big dir?)
//       Make "Orange Soda Fix" screencast.


#define _POSIX_C_SOURCE 199309L  // So nanosleep gets defined:
#include <time.h>                // nanosleep
#include <stdio.h>   // fputs, stderr
#include <unistd.h>  // execvp, sleep
#include <wordexp.h> // wordexp
#include <pwd.h>     // getpwuid
#include <string.h>  // strlen, memset
#include <strings.h> // strcasecmp
#include <stdlib.h>  // malloc, exit, atoi
#include <fcntl.h>   // open, fcntl
#include <libgen.h>  // dirname
#include <errno.h>   // errno
#include <ctype.h>   // isdigit
#include "abspath.h" // abspath
#include "makedirs.h"// makedirs
#include "strdup.h"  // strdupa

#define HEADER_SIZE 1  /* MasterLock */

// The indirection is nicely explained here: http://www.guyrutenberg.com/2008/12/20/expanding-macros-into-string-constants-in-c/
#define VALUE_TO_STRING(x) #x
#define VALUE(x) VALUE_TO_STRING(x)

char** duplicate_argv_with_null_termination(int argc, char** argv) {
    // The process's argv that we receive in main() is not able to be used by execvp for several reasons:
    //     1) We can't assume that we can modify it (for the first and last elements).
    //     2) We can't assume that those memory regions will behave normally during an exec.
    //     3) We can't assume that it is null-terminated.
    // Therefore, we need to duplicate the array ourselves before adding a null-terminator.
    char **argv0;
    argv0 = malloc((argc+1) * sizeof(*argv0)); if(!argv0) { fputs("out of memory\n", stderr); exit(111); }
    for(int i=1; i<argc; i++) argv0[i] = argv[i];
    argv0[argc] = NULL;  // Must terminate the execvp args array with NULL.
    return argv0;
}

void run_target_cmd(char* cmd, char** argv0) {
    // argv0 must be null-terminated.
    argv0[0] = cmd;
    execvp(argv0[0], argv0);  // Note that execvp IS affected by PATH
    perror("exec");
    exit(113);
}

int startswith(char* string, char* prefix) {
    while(*prefix) {
        if(*prefix++ != *string++) return 0;
    }
    return 1;
}

int isIntString(char* s) {
    int l = strlen(s);
    if(!l) return 0;
    int i=0;
    if(s[i]=='+'  ||  s[i]=='-') {  // A leading sign is OK.
        i++;
        if(i >= l) return 0;  // No digits after sign.
    }
    for(; i<l; i++) {
        if(!isdigit(s[i])) return 0;
    }
    return 1;
}

char* expand_lockfile_path(char* path) {
    // We use the very powerful wordexp() function, which could be dangerous if
    // used incorrectly.
    char *finalPath = NULL;
    wordexp_t expansion = {0};
    int err = wordexp(path, &expansion, WRDE_NOCMD|WRDE_SHOWERR|WRDE_UNDEF);
    if(err) {
        switch(err) {
            case WRDE_NOSPACE:
                fputs("WRDE_NOSPACE (Ran out of memory.)\n", stderr);
                break;
            case WRDE_BADCHAR:
                fputs("WRDE_BADCHAR (A metachar appears in the wrong place.)\n", stderr);
                break;
            case WRDE_BADVAL:
                fputs("WRDE_BADVAL (Undefined var reference with WRDE_UNDEF.)\n", stderr);
                break;
            case WRDE_CMDSUB:
                fputs("WRDE_CMDSUB (Command substitution with WRDE_NOCMD.)\n", stderr);
                break;
            case WRDE_SYNTAX:
                fputs("WRDE_SYNTAX (Shell syntax error.)\n", stderr);
                break;
            default: fputs("Unknown wordexp error!\n", stderr);
        }
        goto onError;
    }
    if(expansion.we_wordc != 1) {
        fputs("Invalid lockfile expansion.  Expected ONE word.\n", stderr);
        goto onError;
    }
    finalPath = abspath(expansion.we_wordv[0], NULL);
    if(!finalPath) {
        perror("abspath");
        fputs("Error converting expanded path to abspath.\n", stderr);
        fprintf(stderr, "word: %s\n", expansion.we_wordv[0]);
        goto onError;
    }
    goto cleanup;
    
onError:
    if(finalPath) {
        free(finalPath);
        finalPath = NULL;
    }
cleanup:
    if(expansion.we_wordv) wordfree(&expansion);
    return finalPath;
}

void obtain_exclusive_lock(int fd) {
    while(1) {
        struct flock lock = {0};
        lock.l_type = F_WRLCK;
        lock.l_start = 0;
        lock.l_whence = SEEK_SET;
        lock.l_len = HEADER_SIZE;
        int retcode = fcntl(fd, F_SETLKW, &lock);
        if(!retcode) break;
        perror("fcntl(A)");
        fprintf(stderr, "Trying again...\n");
        sleep(1);  // Once I actually experience this in real life, I might decide to sleep longer or shorter.
    }
}
void release_exclusive_lock(int fd) {
    struct flock lock = {0};
    lock.l_type = F_UNLCK;
    lock.l_start = 0;
    lock.l_whence = SEEK_SET;
    lock.l_len = 1;
    int retcode = fcntl(fd, F_SETLK, &lock);
    if(retcode) perror("fcntl(B)");
}

typedef struct _intPair {
    int first;
    int last;
} intPair;

int isPositionPastAllLocks(int fd, struct flock lock, int i) {
    /*
    Returns 1 if the position given by int 'i' is past
    all locks, and otherwise returns 0
    */
    memset(&lock, 0, sizeof(lock));
    lock.l_type = F_WRLCK;
    lock.l_start = HEADER_SIZE + i;
    lock.l_whence = SEEK_SET;
    lock.l_len = 0;  // 0 means 'everything'.
    int retcode = fcntl(fd, F_GETLK, &lock);
    if(retcode < 0) {
        perror("fcntl(C)");
        //return -1; // or this should exit() ?
        exit(30); // Added by Ryan
    }

    if (lock.l_pid) {
        return 0;
    } else {
        return 1;
    }
}

int isPositionPastAnyLocks(int fd, struct flock lock, int i) {
    /* 
    Returns 1 if the position given by int 'i' is past
    any locks, and otherwise returns 0
    */
    memset(&lock, 0, sizeof(lock));
    lock.l_type = F_WRLCK;
    lock.l_start = HEADER_SIZE + i;
    lock.l_whence = SEEK_SET;
    lock.l_len = 1;
    int retcode = fcntl(fd, F_GETLK, &lock);
    if(retcode < 0) {
        perror("fcntl(E)");
        //return -1; // or this should exit() ?
        exit(30); // Added by Ryan
    }

    if (lock.l_pid) {
        return 1;
    } else {
        return 0;
    }
}

intPair find_firstAndLast_slots(int fd) {
    //static int SAVED_I = 0; //RYANDEBUG
    intPair result = {-1, -1};

    // First, increase 'i' until we are past all locks:
    int i = 1;
    struct flock lock;

    while(1) {
        if (isPositionPastAllLocks(fd, lock, i)) break;  // we are now past all locks
        i *= 2;
    }

    //fprintf(stderr, "%d\n", SAVED_I);    //RYANDEBUG
    //SAVED_I = i;    //RYANDEBUG
    //fprintf(stderr, "%d\n", i);    //RYANDEBUG

    // Now subtract from 'i' until we hit a lock:
    // TODO: Switch this to a binary search algorithm.
    for(i--; i>=0; i--) {
        if (!isPositionPastAllLocks(fd, lock, i)) break; // we hit a lock while stepping backward
    }
    result.last = i;
    if(result.last < 0) return result;  // The first slot will also be -1.

    // Now find the first lock:
    // TODO: Switch this to a binary search algorithm.
    for(i=0; i<result.last; i++) {
        if (isPositionPastAnyLocks(fd, lock, i)) break; // we hit a lock while stepping forward
    }
    result.first = i;
    fprintf(stderr, "{%d,%d}\n", result.first, result.last);    //RYANDEBUG
    return result;
}

void wait_for_my_turn(char* lock_path, int concurrency, int maxQueueSize, int autoCreateDirs) {
    // Here is a diagram of the file layout:
    //
    // MasterLock(byte) | Slot[0](byte) | Slot[1](byte) | ... | Slot[MAX_QUEUE_SIZE-1](byte)
    //
    // The MasterLock is used to synchronize changes between processes.
    // The Slots are used for record locking -- one per process.

    if(autoCreateDirs) {
        char *parentDir = dirname(strdupa(lock_path)); // Do NOT free() return value of dirname.
        makedirs(parentDir);
    }

    int fd = open(lock_path, O_RDWR|O_CREAT, 0600);
    if(fd < 0) {
        perror("open");
        return;
    }

    // Lock the file and claim a slot.
    obtain_exclusive_lock(fd);

    // At this point, we have exclusive control over the file.
    // We can do things non-atomically.
    intPair boundSlots = find_firstAndLast_slots(fd);
    int mySlotNum = boundSlots.last + 1;
    struct flock lock;
    memset(&lock, 0, sizeof(lock));
    lock.l_type = F_WRLCK;
    lock.l_start = HEADER_SIZE + mySlotNum;
    lock.l_whence = SEEK_SET;
    lock.l_len = 1;
    int retcode = fcntl(fd, F_SETLK, &lock);
    if(retcode < 0) perror("fcntl(F)");

    // Done with exclusive lock.
    release_exclusive_lock(fd);

    // Now wait for our turn:
#define MIN_SLEEP_TIME 0.05
#define MAX_SLEEP_TIME 10
    double secondsToSleep = MIN_SLEEP_TIME; // Use an exponential backoff.
    int prevActiveLocks = -1;
    for(;; boundSlots = find_firstAndLast_slots(fd)) {
        // Before using slow iteration, just try to use logic and subtraction:
        if(boundSlots.first < 0) break; // We are the only thing in line.
        if(mySlotNum-boundSlots.first < concurrency) break;

        // We need to iterate:
        int i = boundSlots.first;
        int activeLocks = 1; // For My Lock.
        if(i < mySlotNum) {
            i++;  // Because we already know that boundSlots.first is locked.
            activeLocks++;  // Count the First as well as My Lock.
        }
        // In the loop test below, we do not want to test our own lock because we will be able to obtain it despite the lock.
        while(i<mySlotNum) {  // This used to be a 'for' loop, but GCC kept complaining that it had "no effect" so I switched it to a while loop to silence the warning.
            memset(&lock, 0, sizeof(lock));
            lock.l_type = F_WRLCK;
            lock.l_start = HEADER_SIZE + i;
            lock.l_whence = SEEK_SET;
            lock.l_len = 1;
            retcode = fcntl(fd, F_GETLK, &lock);
            if(retcode < 0) {
                perror("fcntl(G)");
                break;
            }
            if(lock.l_pid) activeLocks++;
            i++;
        }
        if(activeLocks <= concurrency) break;
        if(maxQueueSize>=0  &&  activeLocks-concurrency>maxQueueSize) {
            fprintf(stderr, "MAX_Q exceeded!  Aborting.\n");
            exit(99);
        }
        if(activeLocks != prevActiveLocks) {
            secondsToSleep *= 0.618;
            double logicalMinTime = MIN_SLEEP_TIME * activeLocks / concurrency / 2;
            if(secondsToSleep < logicalMinTime) secondsToSleep = logicalMinTime;
            if(secondsToSleep < MIN_SLEEP_TIME) secondsToSleep = MIN_SLEEP_TIME;
        } else {
            secondsToSleep *= 1.382;
            if(secondsToSleep > MAX_SLEEP_TIME) secondsToSleep = MAX_SLEEP_TIME;
        }
        prevActiveLocks = activeLocks;

        struct timespec secondsToSleep_struct;
        secondsToSleep_struct.tv_sec = (int)secondsToSleep;
        secondsToSleep_struct.tv_nsec = (long)((secondsToSleep - (int)secondsToSleep) * 1000000000);
        nanosleep(&secondsToSleep_struct, NULL);
    }
}

void help(char** argv) {
    fprintf(stderr, "\n");
    fprintf(stderr, "This program is a FIFO worker queue wrapper, capable of running multiple workers at once.\n");
    fprintf(stderr, "Written by Christopher Sebastian, 2013-08-15, csebastian3@gmail.com -- BSD License.\n");
    fprintf(stderr, "\n");
    fprintf(stderr, "Typical usage:\n");
    fprintf(stderr, "\n");
    fprintf(stderr, "    COMMAND=/usr/bin/rsync  LOCKFILE='~/.tmp/backups.lock'  %s [Command Args...]\n", argv[0]);
    fprintf(stderr, "        # COMMAND is the command to run.  I highly suggest using an absolute path.\n");
    fprintf(stderr, "        # LOCKFILE is the path to the lock file.  More info below.\n");
    fprintf(stderr, "        # The Command Args get passed on directly to the COMMAND.\n");
    fprintf(stderr, "\n");
    fprintf(stderr, "Use CONCURRENCY to control the number of workers to run at once.  CONCURRENCY=5 would run 5 workers.\n");
    fprintf(stderr, "Use MAX_Q to control the maximum queue size.  Value of -1 means unlimited.\n");
    fprintf(stderr, "Set AUTO_CREATE_DIRS=0 to prevent the lockfile parent directories from being auto-created.\n");
    fprintf(stderr, "Set Q_HELP=1 to force this help message to be shown.\n");
    fprintf(stderr, "\n");
    fprintf(stderr, "You can use the tilde (~) and environment variables ($) in the LOCKFILE.\n");
    fprintf(stderr, "This enables you to achieve some interesting queuing structures:\n");
    fprintf(stderr, "\n");
    fprintf(stderr, "    LOCKFILE=example.lock                    # A relative path can make it easy to separate tasks based on directory.\n");
    fprintf(stderr, "    LOCKFILE=/tmp/shared.lock                # If you chmod 666 it, you can share the queue with other users on the system.\n");
    fprintf(stderr, "    LOCKFILE='~/cgi.lock'                    # Run N CGI processes per account.\n");
    fprintf(stderr, "    LOCKFILE='~/.tmp/cgi_$SERVER_NAME.lock'  # Run N CGI processes per domain.\n");
    fprintf(stderr, "\n");
#if defined(COMMAND) || defined(LOCKFILE) || defined(AUTO_CREATE_DIRS) || defined(CONCURRENCY) || defined(MAX_Q)
    fprintf(stderr, "Hard-Coded Values (Defined at compile time):\n");
    fprintf(stderr, "\n");
#ifdef COMMAND
    fprintf(stderr, "    COMMAND=" VALUE(COMMAND) "\n");
#endif
#ifdef LOCKFILE
    fprintf(stderr, "    LOCKFILE=" VALUE(LOCKFILE) "\n");
#endif
#ifdef CONCURRENCY
    fprintf(stderr, "    CONCURRENCY=" VALUE(CONCURRENCY) "\n");
#endif
#ifdef MAX_Q
    fprintf(stderr, "    MAX_Q=" VALUE(MAX_Q) "\n");
#endif
#ifdef AUTO_CREATE_DIRS
    fprintf(stderr, "    AUTO_CREATE_DIRS=" VALUE(AUTO_CREATE_DIRS) "\n");
#endif
    fprintf(stderr, "\n");
#endif
}

int main(int argc, char** argv) {

#ifdef COMMAND
    char* command = VALUE(COMMAND);
#else
    char* command = getenv("COMMAND");
#endif
    if(command == NULL) {
        help(argv);
        exit(1);
    }

#ifdef LOCKFILE
    char* lockfile = VALUE(LOCKFILE);
#else
    char* lockfile = getenv("LOCKFILE");
#endif
    if(lockfile == NULL) {
        help(argv);
        exit(2);
    }

#ifdef CONCURRENCY
    int concurrency = CONCURRENCY;
#else
    int concurrency = 1;
    if(getenv("CONCURRENCY") != NULL) {
        if(!isIntString(getenv("CONCURRENCY"))) {
            fprintf(stderr, "CONCURRENCY is non-integer!\n");
            help(argv);
            exit(3);
        }
        concurrency = atoi(getenv("CONCURRENCY"));
    }
#endif
    if(concurrency < 1) {
        fprintf(stderr, "CONCURRENCY is less than 1!\n");
        help(argv);
        exit(3);
    }

#ifdef MAX_Q
    int maxQueueSize = MAX_Q;
#else
    int maxQueueSize = -1;
    if(getenv("MAX_Q") != NULL) {
        if(!isIntString(getenv("MAX_Q"))) {
            fprintf(stderr, "MAX_Q is non-integer!\n");
            help(argv);
            exit(4);
        }
        maxQueueSize = atoi(getenv("MAX_Q"));
    }
#endif
    if(maxQueueSize < -1) {
        fprintf(stderr, "MAX_Q is invalid!\n");
        help(argv);
        exit(4);
    }

#ifdef AUTO_CREATE_DIRS
    int autoCreateDirs = AUTO_CREATE_DIRS;
#else
    int autoCreateDirs = 1;
    if(getenv("AUTO_CREATE_DIRS") != NULL) {
        if(     !strcmp(getenv("AUTO_CREATE_DIRS"), "0")  ||
            !strcasecmp(getenv("AUTO_CREATE_DIRS"), "no")  ||
            !strcasecmp(getenv("AUTO_CREATE_DIRS"), "false") )
            autoCreateDirs = 0;
    }
#endif

    if(getenv("Q_VERBOSE")) fprintf(stderr, "COMMAND=%s  LOCKFILE=%s  CONCURRENCY=%d  MAX_Q=%d  AUTO_CREATE_DIRS=%d\n", command, lockfile, concurrency, maxQueueSize, autoCreateDirs);

    char* abs_lockfile = expand_lockfile_path(lockfile);
    if(!abs_lockfile) {
        fprintf(stderr, "Invalid lock file path.  Skipping to launch...\n");
        goto launchTime;
    }

    wait_for_my_turn(abs_lockfile, concurrency, maxQueueSize, autoCreateDirs);

launchTime:
    run_target_cmd(command, duplicate_argv_with_null_termination(argc, argv));
    return 125; // We should never get here.
}
