// Useful system limits:  /proc/sys/kernel/sem
// 250     32000   32      128
// 4096    256000  800     4096

#define _XOPEN_SOURCE 500

#include <stdio.h>    // printf
#include <sys/ipc.h>  // ftok
#include <sys/sem.h>  // semget, semop, sembuf
#include <sys/stat.h> // S_IRWXU

#define MY_APP_ID 27

// Taken from sys/sem.h.  It tells us to define this ourselves.  :/
union semun {
    int val;                   // value for SETVAL
    struct semid_ds *buf;      // buffer for IPC_STAT & IPC_SET
    unsigned short int *array; // array for GETALL & SETALL
    struct seminfo *__buf;     // buffer for IPC_INFO
};



int get_key() {
    int key = ftok("/tmp/test.lock", MY_APP_ID);
    if(key < 0) {
        // Error.  File is probably not accessible or doesn't exist.
        perror("ftok");
    }
    printf("key = %x\n", key);
    return key;
}

void test_semaphores(int key) {
    int semid = semget(key, 1, IPC_CREAT|S_IRWXU);
    if(semid < 0) {
        perror("semget");
    }



    ///////  Experiment with GETVAL and SETVAL:
    unsigned short semval = semctl(semid, 0, GETVAL);
    if(semval < 0) {
        perror("semctl(GETVAL)");
    }
    printf("GETVAL = %d\n", semval);

    int retcode = semctl(semid, 0, SETVAL, semval+1);
    if(retcode < 0) {
        perror("semctl(SETVAL)");
    }

    semval = semctl(semid, 0, GETVAL);
    if(semval < 0) {
        perror("semctl(GETVAL)");
    }
    printf("GETVAL = %d\n", semval);



    ////// Try waiting for a positive increment of the semaphore:
    struct sembuf mysembuf;
    mysembuf.sem_num = 0;
    mysembuf.sem_op = 1;
    mysembuf.sem_flg = SEM_UNDO;
    retcode = semop(semid, asdf, 1);

}

int main(int argc, char** argv) {
    int key = get_key();
    test_semaphores(key);
    return 2;
}
