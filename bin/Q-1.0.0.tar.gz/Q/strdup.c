// This was created as a separate module to isolate the namespace pollution of _GNU_SOURCE.

#define _GNU_SOURCE
#include <string.h>

