#ifndef _SEB_ABSPATH_H
#define _SEB_ABSPATH_H

char * abspath (const char *name, char *resolved);

#endif
