// LAST UPDATE: 2013-08-03

#include <stdio.h>    // fprintf
#include <stdlib.h>   // malloc
#include <string.h>   // str functions
#include <stdarg.h>   // variadic args
#include <stdint.h>   // UINTPTR_MAX

#include "sebC.h"

#define EMERGENCY_BUF_SIZE 1024
char emergencyBuf[EMERGENCY_BUF_SIZE]; // Used during emergencies when we can't assume that malloc will work.

void seb_defaultErrHandler(char *msg, ...) {
    va_list args;
    va_start(args, msg);
    fprintf(stderr, "Error: ");
    vfprintf(stderr, msg, args);
    fprintf(stderr, "\n");
    exit(99);
}
void (*seb_die)(char*, ...) = seb_defaultErrHandler;

void seb_hexDump(FILE *f, void *data, int size) {
    char *_data = (char *) data;
    int i;
    for(i=0; i<size; i++) {
        if(i!=0) fprintf(f, " ");
        fprintf(f, "%x", _data[i]);
    }
}

char* seb_snprintf(char *buf, size_t bufLen, char *format, ...) {
    va_list args;
    va_start(args, format);
    int charsWritten = vsnprintf(buf, bufLen, format, args);
    if(charsWritten==-1  ||  charsWritten>=bufLen) buf[0] = '\0';
    va_end(args);
    return buf;
}
char* seb_itoa(char *buf, size_t bufLen, int i) {
    return seb_snprintf(buf, bufLen, "%d", i);
}

seb_strSplitPair_t seb_strSplit_r1(char *s, char delim) {
    char *posP = strrchr(s, delim);
    int pos = posP ? posP - s : -1;
    int sLen = strlen(s);

    int leftLen = (pos==-1 ? 0 : pos);
    char *left = malloc(leftLen + 1);  // +1 for null.
    strncpy(left, s, leftLen+1);
    left[leftLen] = '\0';

    char *right = malloc(sLen - pos);
    strncpy(right, s+(pos+1), sLen-(pos+1));
    right[sLen] = '\0';

    seb_strSplitPair_t pair = {left, right};
    return pair;
}

int seb_startswith(char* string, char* prefix) {
    while(*prefix) {
        if(*prefix++ != *string++) return 0;
    }
    return 1;
}


// Detect if we're working with a 32-bit or 64-bit architecture:
#if UINTPTR_MAX == 0xffffffff
#define SIZE_T_FORMAT "%u"  /* 32-bit */
#else
#define SIZE_T_FORMAT "%lu" /* Assume 64-bit */
#endif
size_t original_stack_address = 0;
void seb_printStackTop(const char *type) {
    // Useful for checking whether your tail-recursive funcion is operating properly.
    int stack_top;
    if(original_stack_address == 0) original_stack_address = (size_t) &stack_top;
    fprintf(stderr, "In %s call, the stack top offset is: " SIZE_T_FORMAT "\n", type, (original_stack_address - (size_t) &stack_top));
}




void seb_runTests() {
    int i1 = 0x12345678;
    HEX_DUMP(&i1, sizeof(i1));

    char s1[] = "abcdefgh";
    HEX_DUMP(s1, sizeof(s1));

    seb_strSplitPair_t p1;
    p1 = seb_strSplit_r1("abc:def", ':');
    HEX_DUMP(p1.left,4);
    HEX_DUMP(p1.right,4);

    p1 = seb_strSplit_r1("def", ':');
    HEX_DUMP(p1.left,4);
    HEX_DUMP(p1.right,4);

    p1 = seb_strSplit_r1(":def", ':');
    HEX_DUMP(p1.left,4);
    HEX_DUMP(p1.right,4);

    p1 = seb_strSplit_r1("abc:", ':');
    HEX_DUMP(p1.left,4);
    HEX_DUMP(p1.right,4);

    int bufSize = 10;
    char *buf = malloc(bufSize);
    strcpy(buf, "123456");
    HEX_DUMP(buf, bufSize+1);
    seb_itoa(buf, bufSize, 0);
    HEX_DUMP(buf, bufSize+1);
    seb_itoa(buf, bufSize, 10);
    HEX_DUMP(buf, bufSize+1);
    seb_itoa(buf, bufSize, 1000);
    HEX_DUMP(buf, bufSize+1);
    fprintf(stderr, "seb_itoa overflow result: '%s'\n", seb_itoa(buf, bufSize, 10000));
    HEX_DUMP(buf, bufSize+1);
    fprintf(stderr, "seb_itoa overflow result: '%s'\n", seb_itoa(buf, bufSize, -1000));
    HEX_DUMP(buf, bufSize+1);
}

