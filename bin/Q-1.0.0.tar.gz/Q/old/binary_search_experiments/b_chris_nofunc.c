#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

// http://stackoverflow.com/questions/1598773/is-there-a-standard-function-in-c-that-would-return-the-length-of-an-array#1598827
#define COUNT_OF(x) ((sizeof(x)/sizeof(0[x])) / ((size_t)(!(sizeof(x) % sizeof(0[x])))))

typedef struct _intPair {
    int first;
    int last;
} intPair;

/* locks are located from LOCKS[12] to LOCKS[34] */
int LOCKS[] = {0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int LOCKS_LEN = COUNT_OF(LOCKS);

/* first True value is isPositionPastAllLocks(35) */
int isPositionPastAllLocks(int i) {
    for (i; i<LOCKS_LEN; i++) {
        if (LOCKS[i] == 1) return 0;
    }
    return 1;
}

/* first True value is isPositionPastAnyLocks(13) */
int isPositionPastAnyLocks(int i) {
    int z = 0;
    for (z=0; z<=i; z++) {
        if (LOCKS[z] == 1) return 1;
    }
    return 0;
}

/* must return {12, 34} to be of any use */
intPair find_firstAndLast_slots() {
    intPair result = {-1, -1};

    int i = 1;
    int j;
    int pastAllLocks = 0;
    int pastAnyLocks = 0;

    while(1) {
        pastAllLocks = 1;
        for (j=i; j<LOCKS_LEN; j++) {
            if (LOCKS[j] == 1) {
                pastAllLocks = 0;
                break;
            }
        }
        if (pastAllLocks) break;
        i *= 2;
    }

    for(i--; i>=0; i--) {
        pastAllLocks = 1;
        for (j=i; j<LOCKS_LEN; j++) {
            if (LOCKS[j] == 1) {
                pastAllLocks = 0;
                break;
            }
        }
        if (!pastAllLocks) break;
    }
    result.last = i;

    if(result.last < 0) return result;  // The first slot will also be -1.

    for(i=0; i<result.last; i++) {
        pastAnyLocks = 0;
        for (j=0; j<=i; j++) {
            if (LOCKS[j] == 1) {
                pastAnyLocks = 1;
                break;
            }
        }
        if (pastAnyLocks) break; // we hit a lock while stepping forward
    }
    result.first = i;

    return result;
}


int main(int argc, char** argv) {
    intPair xy;

    int repitions = 100000;
    for (repitions; repitions>0; repitions--) {
        xy = find_firstAndLast_slots();
    }

    printf("%d,%d\n", xy.first, xy.last);
    return 0;
}

