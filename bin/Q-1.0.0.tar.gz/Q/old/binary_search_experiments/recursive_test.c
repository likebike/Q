#include <stdio.h>
 
size_t st;
 
void PrintStackTop(const char *type)
{
    int stack_top;
    if(st == 0) st = (size_t) &stack_top;
    printf("In %s call version, the stack top is: %lu\n", type, (st - (size_t) &stack_top));
}
 
int TailCallFactorial(int n, int a)
{
    PrintStackTop("tail");
    if(n < 2)
        return a;
    return TailCallFactorial(n - 1, n * a);
}
 
int NormalCallFactorial(int n)
{
    PrintStackTop("normal");
    if(n < 2)
        return 1;
    return NormalCallFactorial(n - 1) * n;
}
 
 
int main(int argc, char *argv[])
{
    st = 0;
    printf("%d\n", TailCallFactorial(10, 1));
    st = 0;
    printf("%d\n", NormalCallFactorial(10));
    return 0;
}
 
