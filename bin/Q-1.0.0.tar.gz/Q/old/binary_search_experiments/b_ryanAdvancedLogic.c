#include <stdio.h>    // printf, fprintf
#include <stdlib.h>    // exit, rand

// http://stackoverflow.com/questions/1598773/is-there-a-standard-function-in-c-that-would-return-the-length-of-an-array#1598827
#define COUNT_OF(x) ((sizeof(x)/sizeof(0[x])) / ((size_t)(!(sizeof(x) % sizeof(0[x])))))

typedef struct _intPair {
    int first;
    int last;
} intPair;

// {12,34}
//int LOCKS[] = {0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

// {12,33}
//int LOCKS[] = {0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

// {12,32}
//int LOCKS[] = {0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

// {12,31}
//int LOCKS[] = {0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

int LOCKS[10000];
int LOCKS_LEN = COUNT_OF(LOCKS);

void populate_LOCKS(int start_index, int end_index) {
    int i;

    // check for overflow
    if (end_index > (LOCKS_LEN - 1)) {
        fprintf(stderr, "Warning: end_index exceeded LOCKS_LEN, using maximum length");
        end_index = LOCKS_LEN - 1;
    }

    // init to 0
    for (i=0; i<LOCKS_LEN; i++) {
        LOCKS[i] = 0;
    }

    // fill range with 1
    for (i=start_index; i<=end_index; i++) {
        LOCKS[i] = 1;
    }

    // insert some zeroes
    for (i=start_index+1; i<=(end_index-1); i++) {
        if ((rand() % 2) - 1 == 0) {
            LOCKS[i] = 0;
        }
    }
}




/* first True value is isPositionPastAllLocks(35) */
int isPositionPastAllLocks(int i) {
    for (i; i<LOCKS_LEN; i++) {
        if (LOCKS[i] == 1) return 0;
    }
    return 1;
}

/* first True value is isPositionPastAnyLocks(13) */
int isPositionPastAnyLocks(int i) {
    int z = 0;
    for (z=0; z<=i; z++) {
        if (LOCKS[z] == 1) return 1;
    }
    return 0;
}

/* must return {12, 34} to be of any use */
intPair find_firstAndLast_slots() {
    intPair prevResult = {-1, -1};
    intPair result = {-1, -1};

    int i = 1;

    //if ((prevResult.first == -1) && (prevResult.last == -1)) {    // we have nothing to go on
    while(1) {
        if (isPositionPastAllLocks(i)) break;
        i *= 2;
    }

    // now we know that the end is somewhere between (i/2) and (i), and we can use a binary search
    // Binary search based on http://www.opensource.apple.com/source/xnu/xnu-792.13.8/libsa/bsearch.c

    int base, nmemb, p, lim;

    base = i >> 1;
    nmemb = base; // an optimization. technically nmemb = (binary_end - binary_start)

    // This includes an extra optimization. Technically we should be going all the way until (lim <= 0),
    // not (lim <= 2), but the way that the numbers work in this case, when nmemb == base, we can cut out
    // a couple of final iterations.

    // If this has bugs in strange corner cases, this is the first place to look. (try "lim <= 0" instead)

    for (lim = nmemb; lim >= 0; lim >>= 1) {
        p = base + (lim >> 1);
        if (lim <= 2) {
            // This is the last iteration. The answer is either (p) or (p-1) depending whether or not
            // we are on the right side or left side of the boundary.
            if (!isPositionPastAllLocks(p)) {
                // left side of the boundary
                result.last = p;
                break;
            } else {
                // right side of the boundary
                result.last = p - 1;
                break;
            }
        } else {
            // We have at least one more iteration after this one, so just determine if
            // we're too far left or too far right, and then continue with the for loop.
            if (!isPositionPastAllLocks(p)) {
                // we're too far left
                // See the bsearch.c source code for comments about (base=p+1) and (lim--).
                base = p + 1;
                lim--;
            }
        }
        // we're too far right
    }

    //printf("DONE! lim: %d, base: %d, p: %d\n", lim, base, p);
    //printf("result.last = %d\n", result.last);
    //exit(0);



    if(result.last < 0) return result;  // The first slot will also be -1.



    // now we need to find the front, which is between 0 and result.last. We also use a binary search for this


    base = 0;
    nmemb = result.last;

    for (lim = nmemb; lim >= 0; lim >>= 1) {
        p = base + (lim >> 1);
        if (lim <= 0) {
            // This is the last iteration. The answer is either (p+1) or (p) depending whether or not
            // we are on the right side or left side of the boundary.
            if (!isPositionPastAnyLocks(p)) {
                result.first = p + 1;
                break;
            } else {
                result.first = p;
                break;
            }
        } else {
            // We have at least one more iteration after this one, so just determine if
            // we're too far left or too far right, and then continue with the for loop.
            if (!isPositionPastAnyLocks(p)) {
                // we're too far left
                // See the bsearch.c source code for comments about (base=p+1) and (lim--).
                base = p + 1;
                lim--;
            } else {
                // we're too far right
            }
        }
    }

    //printf("DONE! lim: %d, base: %d, p: %d\n", lim, base, p);
    //printf("result.first = %d\n", result.first);
    //exit(0);

    return result;
}

void testCombinations() {
    int testPairs_LEN = 1000000;

    srand(time(NULL));

    intPair testPairs[testPairs_LEN];
    intPair xy;

    int i, j;
    for (i=0; i<testPairs_LEN; i++) {
        int val1 = rand() % LOCKS_LEN;
        int val2 = rand() % LOCKS_LEN;

        if (val1 < val2) {
            testPairs[i].first = val1;
            testPairs[i].last = val2;
        } else {
            testPairs[i].first = val2;
            testPairs[i].last = val1;
        }
    }

    for (i=0; i<testPairs_LEN; i++) {
//        printf("-------------------------------------------\n");
        populate_LOCKS(testPairs[i].first, testPairs[i].last);

//        // print LOCKS
//        for (j=0; j<LOCKS_LEN; j++) {
//            printf("%d ", LOCKS[j]);
//        }
//        printf("\n");

//        printf("{%d,%d}\n", testPairs[i].first, testPairs[i].last);
        xy = find_firstAndLast_slots();
//        printf("{%d,%d}\n", xy.first, xy.last);
        if (xy.first != testPairs[i].first) {
            printf("Error -- result.first mismatch!\n");
        }
        if (xy.last != testPairs[i].last) {
            printf("Error -- result.last mismatch!\n");
        }
    }

    //  // print LOCKS
    //  for (i=0; i<LOCKS_LEN; i++) {
    //      printf("%d ", LOCKS[i]);
    //  }
    //  printf("\n");


    //populate_LOCKS(0,0);

    //printf("%d\n", d);
    
    return;
}



int main(int argc, char** argv) {
    testCombinations();

    //intPair xy;

    //int repitions = 100000;
    //for (repitions; repitions>0; repitions--) {
    //    xy = find_firstAndLast_slots();
    //}

    //printf("%d,%d\n", xy.first, xy.last);
    return 0;
}

