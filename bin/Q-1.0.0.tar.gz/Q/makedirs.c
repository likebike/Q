
#define _GNU_SOURCE    // Enable special basename() functionality.  Also enables strdupa.
#include <libgen.h>    // dirname
#include <string.h>    // strcmp, strdupa
#include <unistd.h>    // access
#include <sys/stat.h>  // mkdir
#include <sys/types.h> // mode_t

int makedirs_full(char* path, mode_t mode) {
    // Designed to function similarly to Python's os.makedirs().
    char* parentDir = dirname(strdupa(path));  // Do NOT free() return value of dirname.
    if(strcmp(parentDir, "/") && strcmp(parentDir, ".") && access(parentDir, F_OK)) makedirs_full(parentDir, mode);
    return mkdir(path, mode);
}
int makedirs(char* path) {
    return makedirs_full(path, 0755);
}

